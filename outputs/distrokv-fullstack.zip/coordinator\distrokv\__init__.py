"""DistroKV client coordinator."""
